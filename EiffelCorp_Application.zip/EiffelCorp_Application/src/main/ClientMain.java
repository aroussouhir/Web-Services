package main;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;

import java.util.List;

import shared.IEmploy;
import shared.IEmployManagement;


public class ClientMain {

	public static void main(String[] args) throws RemoteException, MalformedURLException {
		// TODO Auto-generated method stub

		
		

	
	}
	
}

