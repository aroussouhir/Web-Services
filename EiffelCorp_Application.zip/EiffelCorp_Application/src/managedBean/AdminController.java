package managedBean;

import java.nio.file.Paths;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.servlet.http.Part;

import service.AdminService;
import shared.IProduct;
import shared.IEmploy;
import shared.IFeedBack;
import shared.IPurchase;
import shared.IUser;
import shared.IWaiting;




@ManagedBean(name="AdminController")
@SessionScoped

public class AdminController {

	private Part file ;
	
	
	
	private String product_id, feedback_id,purchase_id, waiting_id,employee_id ;

	/* product inputs */
	private String product_description,name,type,price,imageUrl;
	
	
	/* Employee inputs */
	private String firstName, lastName, email, address,age,phoneNumber;   
	private char gender;
	private List<IEmploy> emps;
	
	/* Feedback inputs */
	private String feedback_description,rating;

	
	/* Purchase inputs */
	private String status;
	

	/* Waiting inputs*/
	private String request_date;

	AdminService adminService = new AdminService();
	
	
	@PostConstruct
	public void init() {
		
			this.waiting_id="";
			this.purchase_id="";
	}

	
	public void addEmployee(String employee_id) {
	
		try {
				
				if(age.isEmpty()||Integer.valueOf(age)==null) {
					
					System.out.println("You have to input an age ");
				}if(phoneNumber.isEmpty()||Integer.valueOf(phoneNumber)==null) {
					
					System.out.println("You have to input a phoneNumber ");
				}else if(firstName.isEmpty()) {
					
					System.out.println("You have to input a first name");
				}else if(lastName.isEmpty()) {
					
					System.out.println("You have to input a last name");
				}else if(email.isEmpty()) {
					
					System.out.println("You have to input an email");
				}else if(address.isEmpty()) {
					
					System.out.println("You have to input the address ");
				}
			
			
				System.out.println("[addEmployee function in AdminController]");
			
			if(employee_id.isEmpty() ||  employee_id == null) {
				
				this.adminService.addEmployee(firstName, lastName, email, address, Integer.valueOf(age), gender, Integer.valueOf(phoneNumber));
				
				
				this.firstName="";
				this.lastName="";
				this.address="";
				this.email="";
				this.phoneNumber="";
				this.age="";
				
			}else{
				
				System.out.println("[addEmployee function in AdminController]: employee id is esqual to :"+employee_id);
				
				IEmploy e = this.adminService.searchEmployeeById(Integer.valueOf(employee_id));
				
				if(e!=null) {
					
					e.setFirstName(firstName);
					e.setLastName(lastName);
					e.setEmail(email);
					e.setAddress(address);
					e.setAge(Integer.valueOf(age));
					e.setGender(gender);
					e.setPhoneNumber(Integer.valueOf(phoneNumber));
					
				}
				
			}
				System.out.println("[addEmployee function in AdminController]: employee id = " +Integer.valueOf(employee_id));
				
			
				
				this.employee_id="";
				this.firstName="";
				this.lastName="";
				this.address="";
				this.email="";
				this.phoneNumber="";
				this.age="";
				
				
		}catch(NumberFormatException i) {
			System.out.println("[addEmployee function in AdminController] : numberformatException");
		}
		catch(Exception e){
			System.out.println("[addEmployee function in AdminController] : An error has occured during the addemployee process from the adminController stacktrace : "+e);
			e.printStackTrace();
		}
			
	}
	
	public void addFeedBack(String feedback_id) {
		
	}
	
	/*public void addPurchase(String purchase_id) {

		try {
				
				if(age.isEmpty()||Integer.valueOf(age)==null) {
					
					System.out.println("You have to input an age ");
				}if(phoneNumber.isEmpty()||Integer.valueOf(phoneNumber)==null) {
					
					System.out.println("You have to input a phoneNumber ");
				}else if(firstName.isEmpty()) {
					
					System.out.println("You have to input a first name");
				}else if(lastName.isEmpty()) {
					
					System.out.println("You have to input a last name");
				}else if(email.isEmpty()) {
					
					System.out.println("You have to input an email");
				}else if(address.isEmpty()) {
					
					System.out.println("You have to input the address ");
				}
			
			
				System.out.println("[addEmployee function in AdminController] : Selected ISO for ownerCountry is esqual to :");
			
			if(employee_id.isEmpty()) {
				
				this.adminService.addEmployee(firstName, lastName, email, address, Integer.valueOf(age), gender, Integer.valueOf(phoneNumber));
			
			}else{}
				
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
				
				System.out.println("[addPurchase function in AdminController]: purchase id is esqual to :"+purchase_id + " Edit ending date to : "+ this.end_date);
				
				IPurchase r = this.adminService.searchPurchaseById(Integer.valueOf(purchase_id));
				
				if(r!=null) {
					
					
					this.employee_id="";
					this.product_id="";
					this.purchase_id="";
					
					this.adminService.updatePurchases();
					
					
					
				}
				
			
				System.out.println("[addPurchase function in AdminController]: product id = " +Integer.valueOf(purchase_id));
				
				
				
		}catch(NumberFormatException i) {
			System.out.println("[addPurchase function in AdminController] : The purchase_id is empty");
		}
		catch(Exception e){
			System.out.println("[addPurchase function in AdminController] : An error has occured during the addemployee process from the adminController stacktrace : "+e);
			e.printStackTrace();
		}
	}
	*/
	public void addWaiting(String waiting_id) {
		try {

		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		
		
		IWaiting w = this.adminService.searchWaitingById(Integer.valueOf(waiting_id));
		
		if(w!=null) {
			
			
			w.setRequest_date(formatter.parse(this.request_date));
			
			this.employee_id="";
			this.product_id="";
			this.waiting_id="";
			this.request_date="";
			
		}
		
	
		System.out.println("[addPurchase function in AdminController]: product id = " +Integer.valueOf(purchase_id));
		
		this.employee_id="";
		this.product_id="";
		this.waiting_id="";
		
}catch(NumberFormatException i) {
	System.out.println("[addPurchase function in AdminController] : The waiting_id is empty");
}
catch(Exception e){
	System.out.println("[addPurchase function in AdminController] : An error has occured during the addemployee process from the adminController stacktrace : "+e);
	e.printStackTrace();
}
		
	}
	
	
	
	public void removeEmployee(IEmploy e) {
	
		try {
			this.adminService.removeEmployee(e.getId());
		} catch (RemoteException ex) {
			System.out.println("[removeEmployee function in AdminController] : Remote Exception please check if the interfaces are well implemented.");
			ex.printStackTrace();
		}
	}
		
	public void removeFeedBack(IFeedBack f) {
	
		try {
			this.adminService.removeFeedBack(f.getProduct_id());
		} catch (RemoteException ex) {
			System.out.println("[removeFeedBack function in AdminController] : Remote Exception please check if the interfaces are well implemented.");
			ex.printStackTrace();
		}
	}

	public void removePurchase(IPurchase r){
	
		try {
			this.adminService.removeFeedBack(r.getId());
		} catch (RemoteException ex) {
			System.out.println("[removePurchase function in AdminController] : Remote Exception please check if the interfaces are well implemented.");
			ex.printStackTrace();
		}
	}
	
	public void removeWaiting(IWaiting w) {
		
		try {
			this.adminService.removeWaiting(w.getId());
		} catch (RemoteException ex) {
			System.out.println("[removeWatiting function in AdminController] : Remote Exception please check if the interfaces are well implemented.");
			ex.printStackTrace();
		}
	}
	

	public void editProduct(IProduct c) {
		try {
			
			this.employee_id=""+c.getEmployee_id();
			this.product_id = ""+c.getId();
			this.name=c.getName();
			this.type = c.getType();
			this.price = ""+c.getPrice();
			this.product_description = c.getDescription();
			this.imageUrl=""+c.getImageUrl();
			
			this.file = null ;
			
		} catch (RemoteException e) {
			System.out.println("[editproduct function in AdminController] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
		
	}
	
	public void editEmployee(IEmploy e) {
	
		try {
				
				this.employee_id = ""+e.getId();
				this.firstName = e.getFirstName();
				this.lastName = e.getLastName();
				this.email = e.getEmail();
				this.address = e.getAddress();
				this.age = ""+e.getAge();
				this.gender = e.getGender();
				this.phoneNumber = ""+e.getPhoneNumber();
				
			} catch (RemoteException ex) {
				System.out.println("[editproduct function in AdminController] : Remote Exception please check if the interfaces are well implemented.");
				ex.printStackTrace();
			}
	}
	
	public void editFeedback(IFeedBack f) {
		
		try {
			
			this.feedback_id = ""+f.getId();
			this.product_id = ""+f.getProduct_id();
			this.employee_id = ""+f.getEmployee_id();
			this.feedback_description = f.getDescription();
			this.rating = ""+f.getRating();
		
		} catch (RemoteException ex) {
			System.out.println("[editFeedback function in AdminController] : Remote Exception please check if the interfaces are well implemented.");
			ex.printStackTrace();
		}
	}
	
	public void editPurchase(IPurchase r) {
		try {
			
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			
			this.waiting_id="";
			
			this.purchase_id = ""+r.getId();
			this.product_id = ""+r.getProduct_id();
			this.employee_id = ""+r.getEmployee_id();
			
			//this.status=r.getStatus();
			
		} catch (RemoteException e) {
			System.out.println("[editPurchase function in AdminController] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
	}
	
	public void editWaiting(IWaiting w) {
		
		try{
		
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		
		this.purchase_id="";
		
		this.waiting_id=""+w.getId();
	//	this.product_id = ""+w.getProduct_id();
		this.employee_id = ""+w.getEmployee_id();
		
		this.request_date =""+ formatter.format(w.getRequest_date());
		
	} catch (RemoteException e) {
		System.out.println("[ediWaiting function in AdminController] : Remote Exception please check if the interfaces are well implemented.");
		e.printStackTrace();
	}
	}

	
	public String formatDate(Date date) {
	try {
				
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
				return formatter.format(date);
				
			} catch (Exception e) {
				System.out.println("[editPurchase function in AdminController] : Remote Exception please check if the interfaces are well implemented.");
				e.printStackTrace();
			}
			return null;
		}
		
	
	public List<IUser> getUsers(){
		return this.adminService.getUsers();
	}
	
	
	public List<IFeedBack> getFeedBacks(){
		return this.adminService.getFeedBacks()	;
	}
	
	public List<IPurchase> getPurchases(){
		return this.adminService.getPurchases()	;
	}
	
	public List<IEmploy> getEmployees() {
		emps = this.adminService.getEmployees();
		return emps;
	}
	
	public List<IWaiting> getWaitingList(){
		return this.adminService.getWaitingList();
	}

	
	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getImageUrl() {
		return imageUrl;
	}



	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}



	public String getProduct_id() {
		return product_id;
	}



	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}



	public String getFeedback_id() {
		return feedback_id;
	}



	public void setFeedback_id(String feedback_id) {
		this.feedback_id = feedback_id;
	}



	public String getPurchase_id() {
		return purchase_id;
	}



	public void setPurchase_id(String purchase_id) {
		this.purchase_id = purchase_id;
	}



	public String getWaiting_id() {
		return waiting_id;
	}



	public void setWaiting_id(String waiting_id) {
		this.waiting_id = waiting_id;
	}



	public String getEmployee_id() {
		return employee_id;
	}



	public void setEmployee_id(String employee_id) {
		this.employee_id = employee_id;
	}


	public String getProduct_description() {
		return product_description;
	}


	public void setProduct_description(String product_description) {
		this.product_description = product_description;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	
	public String getPrice() {
		return price;
	}


	public void setPrice(String price) {
		this.price = price;
	}

	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public char getGender() {
		return gender;
	}


	public void setGender(char gender) {
		this.gender = gender;
	}


	public String getPhoneNumber() {
		return phoneNumber;
	}


	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}


	public String getFeedback_description() {
		return feedback_description;
	}


	public void setFeedback_description(String feedback_description) {
		this.feedback_description = feedback_description;
	}


	public String getRating() {
		return rating;
	}


	public void setRating(String rating) {
		this.rating = rating;
	}




	public AdminService getAdminService() {
		return adminService;
	}


	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


	public String getRequest_date() {
		return request_date;
	}

	public void setRequest_date(String request_date) {
		this.request_date = request_date;
	}


	public Part getFile() {
		return file;
	}

	public void setFile(Part file) {
		this.file = file;
	}
	
	
	
	
	
}
