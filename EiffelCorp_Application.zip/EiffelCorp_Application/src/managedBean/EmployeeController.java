package managedBean;

import java.io.IOException;
import java.nio.file.Paths;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.component.html.HtmlOutputText;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.Part;

import service.AdminService;
import shared.IProduct;
import shared.IEmploy;
import shared.IFeedBack;
import shared.IPurchase;
import shared.IWaiting;



@ManagedBean(name="EmployeeController")
@SessionScoped
public class EmployeeController {


	private HtmlOutputText outputText;
	
	
	private int userId; 
	
	
	private Part file ;
	
	
	private int product_purchase_id;
	
	/* Entities id */
	private String product_id, feedback_id,purchase_id, waiting_id,employee_id ;

	/* product inputs */
	private String product_description,name,type,price,imageUrl;
	private IProduct product;
	
	/* Employee inputs */
	private String firstName, lastName, email, address,age,phoneNumber;   
	private char gender;

	
	/* Feedback inputs */
	private String feedback_description,rating;

	
	/* Purchase inputs */
	private String status,start_date,end_date;
	

	/* Waiting inputs*/
	private String date_available,request_date;
	
	
	/*Cathegories arrays*/

	
	AdminService adminService = new AdminService();
	
	
	@PostConstruct
	public void init() {
		
			this.waiting_id="";
			this.purchase_id="";
			
			
			
			try {
				
				FacesContext context = FacesContext.getCurrentInstance();
				IEmploy user = (IEmploy) context.getExternalContext().getSessionMap().get("user");
				this.userId = user.getId();
				
				
				
			
			
				
				System.out.println("[ EmployeeController Constructor] : Employee id : "+ userId);
				
			} catch (RemoteException e) {
				System.out.println("[ EmployeeController Constructor] : Remote Exception Problem with Session");
				
				e.printStackTrace();
			}
	}


	
	public void RedirectWaitingList(int product_id) throws IOException {

		product = this.adminService.searchProductById(product_id);
		System.out.println("[redirectWaitingList function in EmployeeController] with product_id = "+ this.product.getId());
		
		ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
		ec.redirect(ec.getRequestContextPath() + "/WaitingList.xhtml");
	}

	public void RedirectFeedBack(int product_id) throws IOException {

		System.out.println("[RedirectFeedBack function in EmployeeController with product_id = "+ product_id+"]");
		
		ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
		ec.redirect(ec.getRequestContextPath() + "/employeeFeedback.xhtml?id="+product_id);
	}
	
	public void redirectToFeedBack() {

		try {
			
			//boolean check = this.adminService.checkForFeedBack(this.userId);
			ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();

			System.out.println("[redirectToFeedBack function in EmployeeController] : test if employee Feeded back  : ");
			
			
		//if(!check) {
			
			System.out.println("[onCheckoutLoad in product controller function] : i'm in it : ");
			
			
		    	IPurchase r = this.adminService.getLastPurchaseByEmployeeId(this.userId);
		    	
		    	System.out.println("[redirectToFeedBack function in EmployeeController] : miss feedback for product : "+ r.getProduct_id());
				
				ec.redirect(ec.getRequestContextPath() + "/employeeFeedback.xhtml?id="+r.getProduct_id());
			//} 
		
		}catch (IOException e) {
				System.out.println("[redirectToFeedBack function in EmployeeController] : An erro has occured during the onCheckLoad function stacktrace: "+e);
				e.printStackTrace();
			}
	}
	
	

	public void addProduct(String product_id) {
		
		try {
			
			if(price.isEmpty()||Integer.valueOf(price)==null) {
				
				System.out.println("You have to input a price ");
			
			}else if(name.isEmpty()) {
				
				System.out.println("You have to input the product name");
			}else if(product_description.isEmpty()) {
				
				System.out.println("You have to input a description");
			}else if(type.isEmpty()) {
				
				System.out.println("You have to input the product type");
			}else if(file == null) {
				
				System.out.println("You have to input the product image");
			}
		
			//System.out.println("[addproduct function in AdminController] : Selected ISO for ownerCountry is esqual to :");
		
		if(product_id.isEmpty() || product_id==null) {
			
			this.imageUrl = Paths.get(file.getSubmittedFileName()).getFileName().toString();
			
			System.out.println("[addproduct function in AdminController] : Image url : "+ this.imageUrl);
			
			this.adminService.addProduct(name, type, product_description, imageUrl, Long.valueOf(price), this.userId);
			this.name="";
			this.price="";
			this.type="";
			this.product_description="";
			this.imageUrl="";
			this.file = null ;
			
		}else{
			
			System.out.println("[addproduct function in AdminController]: product id is esqual to :"+product_id);
			
			IProduct c = this.adminService.searchProductById(Integer.valueOf(product_id));
			
			if(c!=null) {
				
				c.setName(name);
				c.setEmployee_id(Integer.valueOf(this.userId));
				c.setType(type);
				c.setDescription(product_description);
				c.setImageUrl(imageUrl);
				c.setPrice(Long.valueOf(price));
				
			}
			
		}
			System.out.println("[addproduct function in AdminController]: product id = " +Integer.valueOf(product_id));
			
		
			
			this.product_id="";
			this.name="";
			this.price="";
			this.type="";
			this.product_description="";
			this.imageUrl="";
			
	}catch(NumberFormatException i) {
		System.out.println("[addproduct function in AdminController] : You have to input an number for the price field");
	}
	catch(Exception e){
		System.out.println("[addproduct function in AdminController] : An error has occured during the addproduct process from the adminController stacktrace : "+e);
		e.printStackTrace();
	}
		
	}

	
	public void addEmployee(String employee_id) {
	
		try {
				
				if(age.isEmpty()||Integer.valueOf(age)==null) {
					
					System.out.println("You have to input an age ");
				}if(phoneNumber.isEmpty()||Integer.valueOf(phoneNumber)==null) {
					
					System.out.println("You have to input a phoneNumber ");
				}else if(firstName.isEmpty()) {
					
					System.out.println("You have to input a first name");
				}else if(lastName.isEmpty()) {
					
					System.out.println("You have to input a last name");
				}else if(email.isEmpty()) {
					
					System.out.println("You have to input an email");
				}else if(address.isEmpty()) {
					
					System.out.println("You have to input the address ");
				}
			
			
				System.out.println("[addEmployee function in EmployeeController] : Selected ISO for ownerCountry is esqual to :");
			
			if(employee_id.isEmpty()) {
				
				this.adminService.addEmployee(firstName, lastName, email, address, Integer.valueOf(age), gender, Integer.valueOf(phoneNumber));
			
			}else{
				
				System.out.println("[addEmployee function in EmployeeController]: product id is esqual to :"+product_id);
				
				IEmploy e = this.adminService.searchEmployeeById(Integer.valueOf(employee_id));
				
				if(e!=null) {
					
					e.setFirstName(firstName);
					e.setLastName(lastName);
					e.setEmail(email);
					e.setAddress(address);
					e.setAge(Integer.valueOf(age));
					e.setGender(gender);
					e.setPhoneNumber(Integer.valueOf(phoneNumber));
					
				}
				
			}
				System.out.println("[addEmployee function in EmployeeController]: product id = " +Integer.valueOf(product_id));
				
			
				
				this.employee_id="";
				
		}catch(NumberFormatException i) {
			System.out.println("[addEmployee function in EmployeeController] : You have to input an number for the age field");
		}
		catch(Exception e){
			System.out.println("[addEmployee function in EmployeeController] : An error has occured during the addemployee process from the EmployeeController stacktrace : "+e);
			e.printStackTrace();
		}
			
	}
	
	public String addFeedBack(int product_id) {
		try {
			
		
		if(this.rating.isEmpty() || Integer.valueOf(this.rating)==null) {
			System.out.println("You have to input a rating ");
			return null;
		}else if(feedback_description.isEmpty()) {
			System.out.println("You have to input a description");
			return null;
			
		}
		System.out.println("[ EmployeeController : addFeedBack method ] : \n "
				+ "passed parameter = " + product_id
				+ "product_purchase_id = " + this.product_purchase_id
				+ "userId = " + this.userId);
		this.adminService.addFeedBack(this.product_purchase_id, this.userId, Integer.valueOf(this.rating), this.feedback_description);
		
		return "employeeHistFeedback?faces-redirect=true";
		
	}catch(NumberFormatException i) {
		System.out.println("[addFeedBack function in EmployeeController] : You have to input an number for the rating ");
	}
	catch(Exception e){
		System.out.println("[addFeedBack function in EmployeeController] : An error has occured during the addproduct process from the employeeController stacktrace : "+e);
		e.printStackTrace();
	}
		return null;
	}
	public void goToProductDetails(int ProductID) {
		try {
			this.product = this.adminService.searchProductById(ProductID);
			
			System.out.println("[goToProductDetails function in EmployeeController] : Product_id = " + this.product.getId() );
			ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
			
			ec.redirect(ec.getRequestContextPath() + "/employeePurchase.xhtml");

			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	

	public void addPurchase(int productID) {

		try {
			
		
					
		  
				
				System.out.println("[addPurchase function in EmployeeController] : Original Product_id = " +this.product.getId() );
				System.out.println("[addPurchase function in EmployeeController] : Page Product_id = " + productID );
				
				//System.out.println("[addPurchase function in EmployeeController] : Product_id = " +productID + ", User_id = "+ this.userId);
				
				//System.out.println("[addPurchase function in EmployeeController] : saved Product_id = " +this.product_id);
				
				this.adminService.addPurchase(productID, this.userId);
				ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
				
				ec.redirect(ec.getRequestContextPath() + "/employeeHistPurchase.xhtml");

			
		}catch(NumberFormatException i) {
			System.out.println("[addPurchase function in EmployeeController] : You have to input an number for the age field");
		}
		catch(Exception e){
			System.out.println("[addPurchase function in EmployeeController] : An error has occured during the addemployee process from the EmployeeController stacktrace : "+e);
			e.printStackTrace();
		}
		
	
	}
	
	public void addWaiting(String waiting_id) {
		
	}
	
	
	public void removeProduct(IProduct c) {
		
		try {
			this.adminService.removeProduct(c.getId());
		} catch (RemoteException e) {
			System.out.println("[removeproduct function in EmployeeController] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
	}
	
	
	
	public void removeEmployee(IEmploy e) {
	
		try {
			this.adminService.removeEmployee(e.getId());
		} catch (RemoteException ex) {
			System.out.println("[removeEmployee function in EmployeeController] : Remote Exception please check if the interfaces are well implemented.");
			ex.printStackTrace();
		}
	}
		
	public void removeFeedBack(IFeedBack f) {
	
		try {
			this.adminService.removeFeedBack(f.getProduct_id());
		} catch (RemoteException ex) {
			System.out.println("[removeFeedBack function in EmployeeController] : Remote Exception please check if the interfaces are well implemented.");
			ex.printStackTrace();
		}
	}

	public void removePurchase(IPurchase r){
	
		try {
			this.adminService.removeFeedBack(r.getId());
		} catch (RemoteException ex) {
			System.out.println("[removePurchase function in EmployeeController] : Remote Exception please check if the interfaces are well implemented.");
			ex.printStackTrace();
		}
	}
	
	public HtmlOutputText getOutputText() {
		return outputText;
	}

	public void setOutputText(HtmlOutputText outputText) {
		this.outputText = outputText;
	}

	public void removeWatiting(IWaiting w) {
		
		try {
			this.adminService.removeWaiting(w.getId());
		} catch (RemoteException ex) {
			System.out.println("[removeWatiting function in EmployeeController] : Remote Exception please check if the interfaces are well implemented.");
			ex.printStackTrace();
		}
	}

	public List<IPurchase> getPurchasesByEmployeeId(){
	
		return this.adminService.searchPurchaseByEmployeeId(this.userId);
	
	}
	
	public List<IProduct> searchProductByType(String type){

		System.out.println("[ EmployeeController ] : searchProductByType : "+ type);
		return this.adminService.searchProductsByType(type);
		
	
	}
	
	public List<IProduct> HTProducts(){

		return this.adminService.searchProductsByType("High Tech");
	}
	
	public IProduct getProductById(int product_id) {
		
		this.product_purchase_id=product_id;
		System.out.println("[getproductById function in EmployeeController] : Selected product id : "+product_id);
		
		return this.adminService.searchProductById(product_id);
		
	}
	
	public List<IFeedBack> getFeedBacksByEmployeeId(){
		
		return this.adminService.searchFeedBackByEmployeeId(this.userId);
	}
	
	public void editProduct(IProduct c) {
		try {
			
			this.product_id = ""+c.getId();
			this.name=c.getName();
			this.type = c.getType();
			this.price = ""+c.getPrice();
			this.product_description = c.getDescription();
			
		} catch (RemoteException e) {
			System.out.println("[editproduct function in EmployeeController] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
		
	}
	
	public void editEmployee(IEmploy e) {
	
		try {
				
				this.employee_id = ""+e.getId();
				this.firstName = e.getFirstName();
				this.lastName = e.getLastName();
				this.email = e.getEmail();
				this.address = e.getAddress();
				this.age = ""+e.getAge();
				this.gender = e.getGender();
				this.phoneNumber = ""+e.getPhoneNumber();
				
			} catch (RemoteException ex) {
				System.out.println("[editproduct function in EmployeeController] : Remote Exception please check if the interfaces are well implemented.");
				ex.printStackTrace();
			}
	}
	
	public void editFeedback(IFeedBack f) {
		
		try {
			
			this.feedback_id = ""+f.getId();
			this.product_id = ""+f.getProduct_id();
			this.employee_id = ""+f.getEmployee_id();
			this.feedback_description = f.getDescription();
			this.rating = ""+f.getRating();
		
		} catch (RemoteException ex) {
			System.out.println("[editFeedback function in EmployeeController] : Remote Exception please check if the interfaces are well implemented.");
			ex.printStackTrace();
		}
	}
	
	public void editPurchase(IPurchase r) {
		try {
			
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			
			this.waiting_id="";
			
			this.purchase_id = ""+r.getId();
			this.product_id = ""+r.getProduct_id();
			this.employee_id = ""+r.getEmployee_id();
			this.status=r.getStatus();
			
		} catch (RemoteException e) {
			System.out.println("[editPurchase function in EmployeeController] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
	}
	
	public void editWaiting(IWaiting w) {
		
		try{
		
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		
		this.purchase_id="";
		
		this.waiting_id=""+w.getId();
	//	this.product_id = ""+w.getProduct_id();
		this.employee_id = ""+w.getEmployee_id();
		this.request_date =""+ formatter.format(w.getRequest_date());
		
	} catch (RemoteException e) {
		System.out.println("[ediWaiting function in EmployeeController] : Remote Exception please check if the interfaces are well implemented.");
		e.printStackTrace();
	}
	}

	
	public String formatDate(Date date) {
	try {
				
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
				return formatter.format(date);
				
			} catch (Exception e) {
				System.out.println("[editPurchase function in EmployeeController] : Remote Exception please check if the interfaces are well implemented.");
				e.printStackTrace();
			}
			return null;
		}
	
	public List<IProduct> getEmployeeProducts(){
		try {
			List<IProduct> result = new CopyOnWriteArrayList<IProduct>() ;
			
			for(IProduct c : this.adminService.getProducts() ) {
				
			if (c.getEmployee_id()==this.userId) {
					result.add(c);
			}
			
		}
			return result;
			
		}catch (RemoteException e) {
			System.out.println("[getproducts function in EmployeeController] : Remote Exception please check if the interfaces are well implemented.");
			
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	public List<IProduct> getProducts(){
		
			List<IProduct> result = new CopyOnWriteArrayList<IProduct>() ;
			
			for(IProduct c : this.adminService.getProducts() ) {
				
			/*if (c.getAvailability()) {
					result.add(c);
			}*/
				
				result.add(c);			
			}
			return result;
		//	return null;
		}
	
	public List<IProduct> getProductsNotEmployee()
	{
		List<IProduct> result = new CopyOnWriteArrayList<IProduct>() ;
		
		for(IProduct c : this.adminService.getProductsNotEmployee(this.userId) ) {
			
		/*if (c.getAvailability()) {
				result.add(c);
		}*/
			
			result.add(c);			
		}
		return result;
	}
	
	public IEmploy getEmployee() throws RemoteException {
		return adminService.getEmployeeById(this.userId);
	}
		
	public List<IWaiting> searchWaitingByProductId(int product_id) throws RemoteException
	{
		return adminService.searchWaitingByProductId(product_id);
	}
	
	public List<IWaiting> searchWaitingByEmployeeId() throws RemoteException
	{
		return adminService.searchWaitingByEmployeeId(this.userId);
	}

	public List<IFeedBack> searchFeedBackByProductId(int product_id) throws RemoteException
	{
		System.out.println("[ EmployeeController : searchFeedBackByProductId = "+product_id+"]");
		return adminService.searchFeedBackByProductId(product_id);
	}
	
	
	public void setAvailability(int product_id) throws IOException {
		
		System.out.println("[ EmployeeController : setAvailability method : product_id = "+ product_id);
		this.adminService.setAvailability(product_id);
		ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
		ec.redirect(ec.getRequestContextPath() + "/WaitingList.xhtml?id="+product_id);
		
	}
	
	
	public List<IFeedBack> getFeedBacks(){
		return this.adminService.getFeedBacks()	;
	}
	
	public List<IPurchase> getPurchases(){
		return this.adminService.getPurchases()	;
	}
	
	public List<IEmploy> getEmployees() {
		return this.adminService.getEmployees();
	}
	
	public List<IWaiting> getWaitingList(){
		return this.adminService.getWaitingList();
	}

	
	public int countWaiting(int product_id) throws RemoteException {
		return this.adminService.countWaiting(product_id);
	}
	
	public String employeeName(int employee_id) throws RemoteException
	{
		return this.adminService.employeeName(employee_id);
	}
	
	public String productName(int product_id) throws RemoteException
	{
		return this.adminService.productName(product_id);
	}
	
	/*public Employee getEmployee()
	{
		return this.userId;
	}*/
	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getImageUrl() {
		return imageUrl;
	}



	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}



	public String getProduct_id() {
		return product_id;
	}



	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}



	public String getFeedback_id() {
		return feedback_id;
	}



	public void setFeedback_id(String feedback_id) {
		this.feedback_id = feedback_id;
	}



	public String getPurchase_id() {
		return purchase_id;
	}



	public void setPurchase_id(String purchase_id) {
		this.purchase_id = purchase_id;
	}



	public String getWaiting_id() {
		return waiting_id;
	}



	public void setWaiting_id(String waiting_id) {
		this.waiting_id = waiting_id;
	}



	public String getEmployee_id() {
		return employee_id;
	}



	public void setEmployee_id(String employee_id) {
		this.employee_id = employee_id;
	}

	public String getProduct_description() {
		return product_description;
	}


	public void setProduct_description(String product_description) {
		this.product_description = product_description;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	
	public String getPrice() {
		return price;
	}


	public void setPrice(String price) {
		this.price = price;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public char getGender() {
		return gender;
	}


	public void setGender(char gender) {
		this.gender = gender;
	}


	public String getPhoneNumber() {
		return phoneNumber;
	}


	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}


	public String getFeedback_description() {
		return feedback_description;
	}


	public void setFeedback_description(String feedback_description) {
		this.feedback_description = feedback_description;
	}


	public String getRating() {
		return rating;
	}


	public void setRating(String rating) {
		this.rating = rating;
	}


	public String getStart_date() {
		return start_date;
	}


	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}


	public String getEnd_date() {
		return end_date;
	}


	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}


	public AdminService getAdminService() {
		return adminService;
	}


	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDate_available() {
		return date_available;
	}

	public void setDate_available(String date_available) {
		this.date_available = date_available;
	}

	public String getRequest_date() {
		return request_date;
	}

	public void setRequest_date(String request_date) {
		this.request_date = request_date;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getProduct_purchase_id() {
		return product_purchase_id;
	}

	public void setProduct_purchase_id(int product_purchase_id) {
		this.product_purchase_id = product_purchase_id;
	}

	public Part getFile() {
		return file;
	}

	public void setFile(Part file) {
		this.file = file;
	}
	
	public IProduct getProduct() {
		return product;
	}

	public void setProduct(IProduct product) {
		this.product = product;
	}
	
	
	
}
