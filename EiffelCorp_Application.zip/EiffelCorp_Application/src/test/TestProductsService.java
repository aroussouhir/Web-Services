package test;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.util.List;

import shared.IProduct;
import shared.IProductManagement;
import shared.IEmploy;
import shared.IEmployManagement;


public class TestProductsService {
	
	
	public TestProductsService() throws RemoteException {}

	public boolean testAddProduct(IProductManagement Products, long price) throws RemoteException {
		
		System.out.println("\n*-Start Method addProduct-*");
		
		boolean result = Products.addProduct(price);
		
		for(IProduct c : Products.getProducts())
			displayProduct(c);
		
		System.out.println("\n*-End Method addProduct-*");
		return result;
	
	}

	public boolean testAddProduct(IProductManagement Products, String type, String description, String imageUrl,long price, int saleNumber, int employee_id, boolean availability) throws RemoteException {
		
		System.out.println("\n*-Start Method addProduct-*");
		
		boolean result = Products.addProduct(price);
		
		for(IProduct c : Products.getProducts())
			displayProduct(c);
		
		System.out.println("\n*-End Method addProduct-*");
		return result;
	
	}
	
	
	
	public boolean testRemoveProduct(IProductManagement Products, int id) throws RemoteException  {
		
		System.out.println("\n*-Start Method testRemoveProduct-*");	
		boolean result = false;
		
	try {
		
		result = Products.removeProductById(id);
		
		//Display the returned value 
		for(IProduct c : Products.getProducts())
			displayProduct(c);
		
	}
	catch(Exception e) {
		
		System.out.println("An Error has occurend during the test of remove Product : "+e);
		e.printStackTrace();
	}
		
		System.out.println("\n*-End Method testRemoveProduct-*");		
		return result;
	
	}
	
/*	public boolean testSearchProductByModel(IProductManagement Products, String model) throws RemoteException  {
		
		System.out.println("\n*-Start Method searchProductByModel-*");
		boolean result = false;
		
		try {
			
			List<IProduct> result_Products = Products.searchProductByModel(model);
			
			//Display the returned values
			for(IProduct c : result_Products) {
				displayProduct(c);
				
				if(c.getModel().equals(model))
					result = true;
			}
			
		
				
			
		}
		catch(Exception e) {
			
			System.out.println("An Error has occurend during the test of search Product by model : "+ e);
			e.printStackTrace();
		}
			
		System.out.println("\n*-End Method searchProductByModel-*");
			return result;
		
		
	
	}
	
	public boolean testSearchProductByBrand(IProductManagement Products, String brand) throws RemoteException  {
		
		System.out.println("\n*-Start Method searchProductByBrand-*");	
		boolean result = false;
		
		try {
			
			List<IProduct> result_Products = Products.searchProductByBrand(brand);
			
			//Display the returned values 
			for(IProduct c : result_Products) {
				displayProduct(c);
				
				if(c.getBrand().equals(brand))
					result = true;
			}
			
			
				
			
		}
		catch(Exception e) {
			
			System.out.println("An Error has occurend during the test of search Product by brand : "+ e);
			e.printStackTrace();
		}
		
			System.out.println("\n*-End Method searchProductByBrand-*");	
			return result;
		
	
	}*/
	
	public boolean testSearchProductById(IProductManagement Products, int id)  throws RemoteException {
		
		System.out.println("\n*-Start Method searchProductById-*");	
		boolean result = false;
			
			try {
				
				IProduct result_Product = Products.searchProductById(id);
		
				//Display the returned value 
				displayProduct(result_Product);
					
					if(result_Product.getId() == id)
						result = true;
				
				
				
					
				
			}
			catch(Exception e) {
				
				System.out.println("An Error has occurend during the test of search Product by id : "+ e);
				e.printStackTrace();
			}
				
			System.out.println("\n*-End Method searchProductById-*");		
			return result;
			
		
	
	}
	
/*	public boolean testSetProduct(IProductManagement Products, String model, String changeTo, boolean availability) throws RemoteException  
  {
 

			System.out.println("\n*-Start Method testSetProduct-*");	
			boolean result = true;
			
			try {
				
				List<IProduct> result_Products = Products.searchProductByModel(model);
		
				//Display the returned values
				System.out.println("Before Change  : -------------");
				for(IProduct c : result_Products) {
					
				
					displayProduct(c);
					
					System.out.println("\n -----------------------------------");
					
					c.setModel(changeTo);
					c.setAvailability(availability);
				}
				
				//Display the returned values
				System.out.println("\nAfter Change  : -------------");
				for(IProduct c : Products.getProducts()) {
					
					displayProduct(c);
					
					System.out.println("\n -----------------------------------");
					
					if(c.getModel().equals(model)) 
						result = false;
					
					
				}
					
				
					
				
			}
			catch(Exception e) {
				
				System.out.println("An Error has occurend during the test of set Product opperation : "+ e);
				e.printStackTrace();
			}
				
				System.out.println("\n*-End Method testSetProduct-*");	
				return result;
	
	}*/
	
	public void displayProduct(IProduct c) throws RemoteException  {
		System.out.println("\n Product id : "+c.getId()+" Availability : "+c.getAvailability() + " Price : "+c.getPrice());
	}
	

	public static void main(String[] args) throws RemoteException, MalformedURLException  {
		// TODO Auto-generated method stub
		try {
			
			/*App. Product-Management Test*/
			
			//IProduct product =  (IProduct) Naming.lookup("product");
		//	IProductManagement pm = (IProductManagement) Naming.lookup("productManagement");
			
			
			//IProductManagement Products = (IProductManagement) Naming.lookup("productManagement");
			IProductManagement pm = (IProductManagement) Naming.lookup("rmi://localhost:1100/productManagement");
				
			TestProductsService tests = new TestProductsService();
			
			
			boolean testAddProduct = false,testSearchProductById = false ,testSetProduct = false  ,testRemoveProduct = false ;
			
			
			//testAddProduct = tests.testAddProduct(pm, 1500) && tests.testAddProduct(pm, 2100) && tests.testAddProduct(pm, 310);
			
			testAddProduct = tests.testAddProduct(pm,"BOOK","TEST","carIcon.png", 1000,3,0,true ) && tests.testAddProduct(pm,"CHEST","TEST","carIcon.png", 1000,0,0,true) && tests.testAddProduct(pm,"CHEST","TEST","carIcon.png", 1000,1,0,true);
			
			
		/*	for(IProduct c : Products.getProducts())
				displayProduct(c);*/
		//	testSearchProductByModel = tests.testSearchProductByModel(Products, "polo");
			
		//	testSearchProductByBrand = tests.testSearchProductByBrand(Products, "Volkswagen");
			
		//	testSearchProductById = tests.testSearchProductById(pm,0);
			
		//	testSetProduct = tests.testSetProduct(Products, "polo", "golf",false);
			
		//	testRemoveProduct = tests.testRemoveProduct(pm, 1);

			
			
			System.out.println("\nResult of Tests of ProductService :"
					+"\n testAddProduct : "+ testAddProduct
					+"\n testSearchProductById : "+ testSearchProductById
					+"\n testSetProduct : "+ testSetProduct
					+"\n testRemoveProduct : "+ testRemoveProduct);
			
			//Exception
			 }
		
			 catch (Exception e) {
				 
				 e.printStackTrace();
				 System.out.println("An Error Has Occured while running the client for ProductService Test stacktrace : " + e);
			 }
		
			 }

	}


