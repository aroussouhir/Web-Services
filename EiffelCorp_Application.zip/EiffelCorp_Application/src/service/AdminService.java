package service;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import shared.IEmploy;
import shared.IEmployManagement;
import shared.IFeedBack;
import shared.IFeedBackManagement;
import shared.IProduct;
import shared.IProductManagement;
import shared.IPurchase;
import shared.IPurchaseManagement;
import shared.IUser;
import shared.IWaiting;
import shared.IWaitingManagement;

public class AdminService {

	private List<IProduct> products;
	
	private List<IFeedBack> feedBacks;
	
	private List<IPurchase> purchases;
	
	private List<IEmploy> employees;
	
	private List<IWaiting> waitingList;
	
	private List<IUser> users;
	
	private IProductManagement pm;
	
	private IFeedBackManagement feedBacksManager;
	
	private IPurchaseManagement  purchaseManager ;
	
	private IEmployManagement  employeeManager;
	
	private IWaitingManagement wm;
	
	
	public AdminService() {
	try {
			
			 this.pm = (IProductManagement) Naming.lookup("rmi://localhost:1100/productManagement");

			 this.feedBacksManager = (IFeedBackManagement) Naming.lookup("rmi://localhost:1100/FeedBackManagement");
			
			 this.purchaseManager = (IPurchaseManagement) Naming.lookup("rmi://localhost:1100/purchases");
			
			 this.wm = (IWaitingManagement) Naming.lookup("rmi://localhost:1100/WaitingManagement");
			
			 this.employeeManager = (IEmployManagement) Naming.lookup("rmi://localhost:1099/EmployeeManagement");

			 this.products = new CopyOnWriteArrayList<IProduct>();
			 this.feedBacks = new CopyOnWriteArrayList<IFeedBack>();
			 this.employees = new CopyOnWriteArrayList<IEmploy>();
			 this.purchases = new CopyOnWriteArrayList<IPurchase>();
			 this.waitingList = new CopyOnWriteArrayList<IWaiting>();
			 this.users =  new CopyOnWriteArrayList<IUser>();
			 
		} catch (MalformedURLException e) {
			
			System.out.println("[AdminService constructor] : Malformed URL please check the url that you gave to connect to the RMI servers");
			e.printStackTrace();
		} catch (RemoteException e) {
			
			System.out.println("[AdminService constructor] : Remote Exception please check if the interfaces are implemented in your project");
			e.printStackTrace();
		} catch (NotBoundException e) {
			
			System.out.println("[AdminService constructor] : Not Bound Exception please check if the RMI servers are running");
			e.printStackTrace();
		}
		

	}
	
	
	public boolean addProduct(String name, String type, String description, String imageUrl, long price, int employee_id) {
		try {
			
			return this.pm.addProduct(name, type, description, imageUrl,price,employee_id);
			
			
		
		} catch (RemoteException e) {
			System.out.println("[addProduct function in AdminService] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean addEmployee(String firstName, String lastName, String email, String address, int age, char gender, int phoneNumber) {
		try {
			
			return this.employeeManager.addEmployee(firstName, lastName, email, address, age, gender, phoneNumber);
		
		} catch (RemoteException e) {
			System.out.println("[addEmployee function in AdminService] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean addFeedBack(int Product_id, int employee_id, int rating, String description) {
		try {
			
			return this.feedBacksManager.addFeedBack(Product_id, employee_id, rating, description);
		
		} catch (RemoteException e) {
			System.out.println("[addFeedBack function in AdminService] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean addPurchase(int product_id,int employee_id) {
		try {
			
			if(!pm.searchProductById(product_id).getAvailability() )
			{
				System.out.println("AdminService add to waitingList ok");
				wm.addWaiting(product_id,employee_id);
			}
			else
			{
			boolean r =this.purchaseManager.addPurchase(product_id, employee_id);
			System.out.println("AdminService addPurchase OK");
			return r;
			}
		
		} catch (RemoteException e) {
			System.out.println("[addPurchase function in AdminService] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
		return false;
	}
	
	
	public boolean addPurchase2(int product_id,int employee_id) {
		try {
			
			boolean r =this.purchaseManager.addPurchase(product_id, employee_id);
			System.out.println("AdminService addPurchase OK");
			return r;
			
		
		} catch (RemoteException e) {
			System.out.println("[addPurchase function in AdminService] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
		return false;
	}
	
	

	public IUser searchUserByLoginMdp(String login, String password) {
		try {
			
			return this.employeeManager.searchUserLoginMdp(login, password);
			
		} catch (RemoteException e) {
			System.out.println("[searchUserByLoginMdp function in AdminService] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
		return null;
	}
	
	public IProduct searchProductById(int product_id) {
		try {
			
			return this.pm.searchProductById(product_id);
			
		} catch (RemoteException e) {
			System.out.println("[searchProductById function in AdminService] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
		return null;
	}
	
	public List<IFeedBack> searchFeedBackByEmployeeId(int employee_id) {
	try {
				
				return this.feedBacksManager.searchFeedBackByEmployeeId(employee_id);
				
			} catch (RemoteException e) {
				System.out.println("[searchFeedBackByEmployeeId function in AdminService] : Remote Exception please check if the interfaces are well implemented.");
				e.printStackTrace();
			}
			return null;
	}
	
	public List<IFeedBack> searchFeedBackByProductId(int product_id) throws RemoteException
	{
		System.out.println("[ AdminService : searchFeedBackByProductId = "+product_id+"]");
		
		return this.feedBacksManager.searchFeedBackByProductId(product_id);
	}

	public IEmploy searchEmployeeById(int employee_id) {
	
		try {
				
				return this.employeeManager.searchEmployeeById(employee_id);
				
			} catch (RemoteException e) {
				System.out.println("[searchEmployeeById function in AdminService] : Remote Exception please check if the interfaces are well implemented.");
				e.printStackTrace();
			}
			return null;
	}

	public IPurchase searchPurchaseById(int purchase_id) {
		try {
			
			return this.purchaseManager.searchPurchaseById(purchase_id);
			
		} catch (RemoteException e) {
			System.out.println("[searchPurchaseById function in AdminService] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
		return null;
	}
	
	public IFeedBack searchFeedBackById(int feedback_id) {
		try {
			
			return this.feedBacksManager.searchFeedBackById(feedback_id);
			
		} catch (RemoteException e) {
			System.out.println("[searchFeedBackById function in AdminService] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
		return null;
		}
	
	public IWaiting searchWaitingById(int waiting_id) {
		try {
			
			return this.wm.searchWaitingById(waiting_id);
			
		} catch (RemoteException e) {
			System.out.println("[searchWaitingById function in AdminService] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
		return null;
	}
	
	public List<IPurchase> searchPurchaseByEmployeeId(int employee_id) {
			
			try {
				return this.purchaseManager.searchPurchaseByEmployeeId(employee_id);
			} catch (RemoteException e) {
				System.out.println("[searchPurchaseByEmployeeId function in AdminService] : Remote Exception please check if the interfaces are well implemented.");
				e.printStackTrace();
			}
			return null;
			
		}
	
	
	public boolean removeProduct(int id) {
		try {
			
			return this.pm.removeProductById(id);
			
		} catch (RemoteException e) {
			System.out.println("[removeProduct function in AdminService] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
		return false;
	}

	public boolean removeFeedBack(int id) {
		try {
			
			return this.feedBacksManager.removeFeedBack(id);
			
		} catch (RemoteException e) {
			System.out.println("[removeFeedBack function in AdminService] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean removeEmployee(int id) {
		try {
			
			return this.employeeManager.removeEmployeeById(id);
			
		} catch (RemoteException e) {
			System.out.println("[removeEmployee function in AdminService] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean removePurchase(int id) {
		try {
			
			return this.purchaseManager.removePurchase(id);
			
		} catch (RemoteException e) {
			System.out.println("[removePurchase function in AdminService] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean removeWaiting(int id) {
		try {
			
			return this.wm.removeWaiting(id);
			
		} catch (RemoteException e) {
			System.out.println("[removeWaitingList function in AdminService] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
		return false;
	}
	
	public void updatePurchases() {
		try {
			
			this.purchaseManager.updatePurchases();
			
		} catch (RemoteException e) {
			System.out.println("[updatePurchases function in AdminService] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
		
	}

	public List<IProduct> getProducts() {
		
		try {
			
			this.products.clear();
			
			for(IProduct c : this.pm.getProducts()){
					
				this.products.add(c);
			}
		} 
		catch (RemoteException e) {
			System.out.println("[getproducts function in AdminService] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
		
		return this.products;
	
	}
	
	public List<IProduct> getProductsNotEmployee(int employee_id) {
		
		try {
			
			this.products.clear();
			
			for(IProduct c : this.pm.getProductsNotEmployee(employee_id)){
					
				this.products.add(c);
			}
		} 
		catch (RemoteException e) {
			System.out.println("[getproducts function in AdminService] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
		
		return this.products;
	
	}
	
	public IEmploy getEmployeeById(int employee_id) throws RemoteException
	{
		return this.employeeManager.searchEmployeeById(employee_id);
		
	}
	public List<IProduct> searchProductsByType(String type){
		
		try {
			
			return this.pm.searchProductByType(type);
		} catch (RemoteException e) {
			System.out.println("[searchProductByType function in AdminService] : Remote Exception please check if the interfaces are well implemented.");
			e.printStackTrace();
		}
		return null;
	}

	public List<IWaiting> searchWaitingByProductId(int product_id) throws RemoteException
	{
		return wm.searchWaitingByProductId(product_id);
	}
	
	public List<IWaiting> searchWaitingByEmployeeId(int employee_id) throws RemoteException
	{
		return wm.searchWaitingByEmployeeId(employee_id);
	}
	
	public List<IFeedBack> getFeedBacks() {
		
		try {
			
			this.feedBacks.clear();
			
			for(IFeedBack f : this.feedBacksManager.getFeedBacks()){
				this.feedBacks.add(f);
			}
		} 
		catch (RemoteException e) {
			System.out.println("[getFeedBacks function in AdminService] : Remote Exception please check if the interfaces are well implemented ");
			e.printStackTrace();
		}
		
		return this.feedBacks;
	}

	public List<IPurchase> getPurchases() {
	
		try {
			
			this.purchases.clear();
			
			for(IPurchase r : this.purchaseManager.getPurchases()){
				this.purchases.add(r);
			}
		} 
		catch (RemoteException e) {
			System.out.println("[getPurchases function in AdminService] : Remote Exception please check if the interfaces are well implemented ");
			e.printStackTrace();
		}
		
		return this.purchases;
	}

	
	public List<IEmploy> getEmployees() {
		
			try {
					
					this.employees.clear();
					
					for(IEmploy e : this.employeeManager.getEmployees()){
						this.employees.add(e);
					}
				} 
				catch (RemoteException e) {
					System.out.println("[getEmployees function in AdminService] : Remote Exception please check if the interfaces are well implemented ");
					e.printStackTrace();
				}
			
				
				return this.employees;
			}


	public List<IWaiting> getWaitingList() {
		
		try {
			
			this.waitingList.clear();
			
			for(IWaiting w : this.wm.getWaitingList()){
				this.waitingList.add(w);
			}
		} 
		catch (RemoteException e) {
			System.out.println("[getWaitingList function in AdminService] : Remote Exception please check if the interfaces are well implemented ");
			e.printStackTrace();
		}
		
		return this.waitingList;
	}

	public IPurchase getLastPurchaseByEmployeeId(int userId) {
		try {
			
			 return this.purchaseManager.getLastPurchaseByEmployeeId(userId);
			}
		
		catch (Exception e) {
			System.out.println("[getLastPurchaseByEmployeeId function in AdminService] : Exception please check if the interfaces are well implemented ");
			e.printStackTrace();
		}
		
		return null;
	}


	
	public List<IUser> getUsers() {
		try {
			
			this.users.clear();
			
			for(IUser u : this.employeeManager.getUsers()){
				this.users.add(u);
			}
		} 
		catch (RemoteException e) {
			System.out.println("[getUsers function in AdminService] : Remote Exception please check if the interfaces are well implemented ");
			e.printStackTrace();
		}
		
		return this.users;
	}

	public void setAvailability(int product_id) throws RemoteException
	{
		System.out.println("[ AdminService : setAvailibility : change availability");
			 
		 if(!wm.isEmpty())
		 {
			 System.out.println("[ AdminService : setAvailibility : removing first employee from waiting list");
			 int empId = wm.searchWaitingByProductId(product_id).get(0).getEmployee_id();
			 addPurchase2(product_id, empId);
			 wm.removeFirst();
		 }
		 
		 pm.setAvailability(product_id, wm.isEmpty() );
	}
	
	public int countWaiting(int product_id)throws RemoteException {
		// TODO Auto-generated method stub
		return wm.countWainting(product_id);
	}

	public String employeeName(int employee_id) throws RemoteException
	{
		return this.employeeManager.searchEmployeeById(employee_id).getLastName() + "  "+this.employeeManager.searchEmployeeById(employee_id).getFirstName();
		
	}
	
	public String productName(int product_id) throws RemoteException
	{
		return this.pm.searchProductById(product_id).getName();
		
	}
	
	public void setProducts(List<IProduct> products) {
		this.products = products;
	}

	public void setPurchases(List<IPurchase> purchases) {
		this.purchases = purchases;
	}

	public void setFeedBacks(List<IFeedBack> feedBacks) {
		this.feedBacks = feedBacks;
	}

	public void setEmployees(List<IEmploy> employess) {
		this.employees = employees;
	}

	public void setWaitingList(List<IWaiting> waitingList) {
		this.waitingList = waitingList;
	}

	

	public IProductManagement getProductsManager() {
		return pm;
	}

	public IPurchaseManagement getPurchaseManager() {
		return purchaseManager;
	}

	public IFeedBackManagement getFeedBacksManager() {
		return feedBacksManager;
	}

	public IEmployManagement getEmployeeManager() {
		return employeeManager;
	}
	
	public IWaitingManagement getWaitingListManager() {
		return wm;
	}


	public void setProductsManager(IProductManagement productsManager) {
		this.pm = productsManager;
	}

	public void setFeedBacksManager(IFeedBackManagement feedBacksManager) {
		this.feedBacksManager = feedBacksManager;
	}
	
	public void setPurchasesManager(IPurchaseManagement purchaseManager) {
		this.purchaseManager = purchaseManager;
	}

	public void setEmployeeManager(IEmployManagement employeeManager) {
		this.employeeManager = employeeManager;
	}

	public void setWaitingListManager(IWaitingManagement waitingListManager) {
		this.wm = waitingListManager;
	}


	



	

	


	







}
