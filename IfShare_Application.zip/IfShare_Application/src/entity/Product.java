package entity;

import java.rmi.RemoteException;
import java.util.List;

import shared.IFeedBack;




public class Product {


	private int id, nbSale;
	private String type,description,imageUrl,name;
	float rating;
	private double price;
	
	
	

	public Product() throws RemoteException  {
		super();
	}




	public Product(int id, int nbSale, String name, String type, String description, String imageUrl, double price, float rating) throws RemoteException {
		super();
		this.id = id;
		this.nbSale = nbSale;
		this.name=name;
		this.type = type;
		this.description = description;
		this.imageUrl = imageUrl;
	this.rating = rating;
		

		this.price = price;
	}







	public int getId() throws RemoteException {
		return id;
	}








	public void setId(int id) throws RemoteException {
		this.id = id;
	}





	public double getPrice() throws RemoteException  {
		return price;
	}





	public void setPrice(double price)  throws RemoteException  {
		this.price = price;
	}



	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}

	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getImageUrl() {
		return imageUrl;
	}


	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}




	public int getNbSale() {
		return nbSale;
	}




	public void setNbSale(int nbSale) {
		this.nbSale = nbSale;
	}




	public String getName() {
		return name;
	}




	public void setName(String name) {
		this.name = name;
	}




	
}
